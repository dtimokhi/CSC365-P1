To run the program type:
python3 schoolsearch.py in the terminal
