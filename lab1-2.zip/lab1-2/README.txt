To run the program type:
python3 schoolsearch.py in the terminal

NEW COMMANDS:

class: <class number>  
	This will return all of the students in the class specified.

cteach: <class number>
	This will return all of the teachers that teach in the given classroom.

gteach: <grade number>
	This will return all of the teachers that teach in the given grade.

cenroll
	This will return the enrollment by each classroom.

meang 
	This will return the mean gpa of each student in a given grade value.

meant
	This will return the mean gpa of each student who has a given teacher.

meanb
	This will return the mean gpa of each student who has a given bus route.
